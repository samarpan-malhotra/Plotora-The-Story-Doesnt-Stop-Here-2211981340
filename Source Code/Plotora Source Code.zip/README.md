# Plotora

Plotora is a collaborative movie club and alternate story creation platform.

## Features
- User registration and login
- Create / join movie clubs
- Suggest movies and vote with one-vote-per-user logic
- Deadline-based movie selection
- Submit alternate endings
- Vote on endings and view leaderboard

## Tech Stack
- Frontend: React (Vite)
- Backend: Node.js, Express
- Database: MongoDB (Mongoose)
- Auth: JWT

## Project Structure
- `backend/` REST API server
- `frontend/` React client

## Quick Start

### Backend
1. `cd backend`
2. `cp .env.example .env`
3. Fill `MONGO_URI` and `JWT_SECRET`
4. `npm install`
5. `npm run dev`

### Frontend
1. `cd frontend`
2. `npm install`
3. `npm run dev`

## Notes
This is a clean starter implementation with the core project logic.
