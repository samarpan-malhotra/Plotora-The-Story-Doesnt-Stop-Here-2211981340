import React, { useEffect, useState } from 'react';
import { tmdb } from './api/tmdb';
import { api } from './api/api';

import MovieRow from './components/MovieRow';
import MovieModal from './components/MovieModal';
import LoginModal from './components/LoginModal';
import SearchBar from './components/SearchBar';
import ClubCards from './components/ClubCards';
import Leaderboard from './components/Leaderboard';
import Archive from './components/Archive';
import Logo from './components/Logo';
import HeroBanner from './components/HeroBanner';
import UserProfile from './components/UserProfile';
import WatchlistRow from './components/WatchlistRow';
import ToastContainer from './components/Toast';

function App() {
  const [movies, setMovies] = useState({});
  const [trendingList, setTrendingList] = useState([]);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");
  const [results, setResults] = useState([]);
  const [activeTab, setActiveTab] = useState("movies");
  const [showLogin, setShowLogin] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const [watchlistKey, setWatchlistKey] = useState(0);
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("user") || "null"); } catch { return null; }
  });

  useEffect(() => {
    const handler = (e) => setSelected(e.detail);
    window.addEventListener("plotora:select", handler);
    return () => window.removeEventListener("plotora:select", handler);
  }, []);

  useEffect(() => {
    const handler = () => setWatchlistKey(k => k + 1);
    window.addEventListener("plotora:watchlist-update", handler);
    return () => window.removeEventListener("plotora:watchlist-update", handler);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => { loadMovies(); }, []);

  useEffect(() => {
    const delay = setTimeout(() => {
      if (search.length > 2) {
        tmdb.search(search).then(d => setResults(d.results?.filter(r => r.poster_path) || []));
      } else { setResults([]); }
    }, 300);
    return () => clearTimeout(delay);
  }, [search]);

  async function loadMovies() {
    try {
      const [trending, upcoming, popular, topRated, nowPlaying,
             action, scifi, horror, animation, romance,
             tvTrending, tvPopular, tvTopRated, tvAiring, tvDrama] = await Promise.all([
        tmdb.trending(), tmdb.upcoming(), tmdb.popular(), tmdb.topRated(), tmdb.nowPlaying(),
        tmdb.action(), tmdb.scifi(), tmdb.horror(), tmdb.animation(), tmdb.romance(),
        tmdb.tvTrending(), tmdb.tvPopular(), tmdb.tvTopRated(), tmdb.tvAiring(), tmdb.tvDrama(),
      ]);
      setTrendingList(trending.results || []);
      setMovies({
        "🔥 Trending This Week":   trending.results || [],
        "🎬 Now Playing":          nowPlaying.results || [],
        "⭐ Top Rated":            topRated.results || [],
        "📅 Coming Soon":          upcoming.results || [],
        "💥 Action & Adventure":   action.results || [],
        "🚀 Science Fiction":      scifi.results || [],
        "😱 Horror":               horror.results || [],
        "🎨 Animation":            animation.results || [],
        "💕 Romance":              romance.results || [],
        "🌟 Popular Movies":       popular.results || [],
        "📺 Trending TV Shows":    (tvTrending.results || []).map(s => ({ ...s, media_type: "tv" })),
        "📺 Popular Series":       (tvPopular.results || []).map(s => ({ ...s, media_type: "tv" })),
        "📺 Top Rated Series":     (tvTopRated.results || []).map(s => ({ ...s, media_type: "tv" })),
        "📺 Currently Airing":     (tvAiring.results || []).map(s => ({ ...s, media_type: "tv" })),
        "📺 Drama Series":         (tvDrama.results || []).map(s => ({ ...s, media_type: "tv" })),
      });
    } catch (e) { console.log("Load error:", e); }
  }

  function handleLogin(newToken, newUser) {
    setToken(newToken); setUser(newUser);
    localStorage.setItem("token", newToken);
    localStorage.setItem("user", JSON.stringify(newUser));
    setShowLogin(false);
    setActiveTab("movies");
    // Welcome toast after short delay so UI settles first
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent("plotora:toast", {
        detail: { message: `Welcome back, ${newUser.name}! 🎬`, type: "success" }
      }));
    }, 200);
  }

  function logout() {
    setToken("");
    setUser(null);
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.dispatchEvent(new CustomEvent("plotora:toast", {
      detail: { message: "Logged out successfully", type: "success" }
    }));
  }

  const interestedList = (() => {
    try { return JSON.parse(localStorage.getItem("interested") || "[]"); } catch { return []; }
  })();

  const tabs = [
    { id: "movies", label: "Movies" },
    { id: "clubs", label: "Clubs" },
    { id: "leaderboard", label: "Leaderboard" },
    { id: "archive", label: "Archive" },
  ];

  return (
    <div className="app">

      {/* NAVBAR */}
      <nav style={{
        position: "sticky", top: 0, zIndex: 500,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        padding: "12px 0", marginBottom: "24px",
        background: scrolled ? "rgba(11,16,32,0.92)" : "transparent",
        backdropFilter: scrolled ? "blur(16px)" : "none",
        borderBottom: scrolled ? "1px solid rgba(148,163,255,0.08)" : "1px solid transparent",
        transition: "all 0.3s"
      }}>
        {/* Logo */}
        <div onClick={() => setActiveTab("movies")} style={{ cursor: "pointer", flexShrink: 0 }}>
          <Logo size={36} />
        </div>

        {/* Nav tabs */}
        <div style={{ display: "flex", gap: "4px" }}>
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{
              background: activeTab === tab.id ? "rgba(99,102,241,0.2)" : "transparent",
              border: activeTab === tab.id ? "1px solid rgba(99,102,241,0.4)" : "1px solid transparent",
              borderRadius: "10px", padding: "7px 16px", fontSize: "13px", fontWeight: 600,
              color: activeTab === tab.id ? "#a5b4fc" : "#666",
              transition: "all 0.2s", cursor: "pointer"
            }}>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Auth */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          {user ? (
            <>
              <button onClick={() => setShowProfile(true)} style={{
                display: "flex", alignItems: "center", gap: "8px",
                background: "rgba(255,255,255,0.06)", border: "1px solid rgba(148,163,255,0.15)",
                borderRadius: "20px", padding: "6px 14px 6px 6px", cursor: "pointer"
              }}>
                <div style={{
                  width: "26px", height: "26px", borderRadius: "50%",
                  background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "12px", fontWeight: 800, color: "white"
                }}>
                  {(user.name || "U")[0].toUpperCase()}
                </div>
                <span style={{ fontSize: "13px", color: "#a5b4fc", fontWeight: 600 }}>{user.name}</span>
              </button>
              <button onClick={logout} style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", fontSize: "12px", padding: "7px 12px", borderRadius: "10px" }}>
                Logout
              </button>
            </>
          ) : (
            <button onClick={() => setShowLogin(true)} style={{
              background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
              border: "none", padding: "9px 20px", borderRadius: "12px",
              fontSize: "13px", fontWeight: 700, boxShadow: "0 4px 14px rgba(99,102,241,0.35)"
            }}>
              Sign In
            </button>
          )}
        </div>
      </nav>

      {/* CONTENT */}
      <div>
        {activeTab === "movies" && (
          <>
            <SearchBar value={search} onChange={setSearch} />

            {results.length > 0 && (
              <MovieRow title="🔎 Search Results" movies={results} onSelect={setSelected} />
            )}

            {/* Hero banner when no search */}
            {!results.length && trendingList.length > 0 && (
              <HeroBanner movies={trendingList} onSelect={setSelected} />
            )}

            {/* Watchlist */}
            {!results.length && (
              <WatchlistRow
                key={watchlistKey}
                onSelect={setSelected}
                onUpdate={() => setWatchlistKey(k => k + 1)}
              />
            )}

            {Object.entries(movies).map(([key, val]) => (
              <MovieRow key={key} title={key} movies={Array.isArray(val) ? val : []} onSelect={setSelected} />
            ))}
          </>
        )}

        {activeTab === "clubs" && <ClubCards movies={movies} onSelect={setSelected} />}
        {activeTab === "leaderboard" && <Leaderboard />}
        {activeTab === "archive" && <Archive />}
      </div>

      {/* MODALS */}
      {selected && <MovieModal movie={selected} onClose={() => setSelected(null)} token={token} />}
      {showLogin && <LoginModal onClose={() => setShowLogin(false)} onLogin={handleLogin} />}
      {showProfile && <UserProfile user={user} token={token} onClose={() => setShowProfile(false)} />}

      {/* TOASTS */}
      <ToastContainer />
    </div>
  );
}

export default App;
