import { useState, useEffect } from "react";

export default function UserProfile({ user, token, onClose }) {
  const [stats, setStats] = useState(null);
  const [myStories, setMyStories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || !token) return;
    fetchStats();
  }, [user]);

  async function fetchStats() {
    setLoading(true);
    try {
      // Fetch ALL stories from archive (includes club + direct movie submissions)
      const all = await fetch(`http://localhost:5000/api/story/archive/all`)
        .then(r => r.json()).then(d => Array.isArray(d) ? d : []).catch(() => []);

      const userId = user._id || user.id;
      const mine = all.filter(s => {
        const sid = s.user?._id || s.user?.id || s.user;
        return sid?.toString() === userId?.toString();
      });

      const totalUpvotes   = mine.reduce((s, st) => s + (st.upvotes?.length || 0), 0);
      const totalDownvotes = mine.reduce((s, st) => s + (st.downvotes?.length || 0), 0);
      const score = mine.length + totalUpvotes * 2;

      setMyStories(mine.slice(0, 5));
      setStats({ stories: mine.length, upvotes: totalUpvotes, downvotes: totalDownvotes, score });
    } catch (e) { console.error(e); }
    setLoading(false);
  }

  if (!user) return null;

  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)",
      zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center",
      padding: "20px", backdropFilter: "blur(6px)"
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background: "linear-gradient(160deg, #131929, #0e1422)",
        border: "1px solid rgba(148,163,255,0.2)", borderRadius: "20px",
        padding: "32px", width: "100%", maxWidth: "460px",
        maxHeight: "80vh", overflowY: "auto", position: "relative"
      }}>
        <button onClick={onClose} style={{
          position: "absolute", top: "14px", right: "14px",
          background: "rgba(255,255,255,0.08)", borderRadius: "50%",
          width: "30px", height: "30px", padding: 0, fontSize: "14px"
        }}>✕</button>

        {/* Avatar */}
        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <div style={{
            width: "72px", height: "72px", borderRadius: "50%",
            background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: "28px", fontWeight: 800, color: "white",
            margin: "0 auto 12px", boxShadow: "0 0 0 4px rgba(99,102,241,0.25)"
          }}>
            {(user.name || "U")[0].toUpperCase()}
          </div>
          <h2 style={{ margin: "0 0 4px", fontSize: "20px" }}>{user.name}</h2>
          <p style={{ color: "#888", fontSize: "13px", margin: 0 }}>{user.email}</p>
        </div>

        {/* Stats grid */}
        {loading ? (
          <p style={{ textAlign: "center", color: "#888" }}>Loading stats...</p>
        ) : stats && (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "10px", marginBottom: "20px" }}>
              {[
                { label: "Endings Written", value: stats.stories, icon: "✍️" },
                { label: "Upvotes Received", value: stats.upvotes, icon: "👍" },
                { label: "Creative Score", value: stats.score, icon: "🏆" },
              ].map(s => (
                <div key={s.label} style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(148,163,255,0.1)",
                  borderRadius: "14px", padding: "14px", textAlign: "center"
                }}>
                  <div style={{ fontSize: "20px", marginBottom: "6px" }}>{s.icon}</div>
                  <div style={{ fontSize: "22px", fontWeight: 800, color: "#a5b4fc" }}>{s.value}</div>
                  <div style={{ fontSize: "10px", color: "#666", marginTop: "2px" }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Recent stories */}
            {myStories.length > 0 && (
              <div>
                <h4 style={{ margin: "0 0 12px", fontSize: "14px", color: "#e2e8f0" }}>📝 Your Recent Endings</h4>
                {myStories.map((s, i) => (
                  <div key={i} style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(148,163,255,0.08)",
                    borderRadius: "10px", padding: "10px 12px", marginBottom: "8px"
                  }}>
                    <p style={{ fontSize: "12px", color: "#bbb", margin: "0 0 6px", lineHeight: 1.5,
                      display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                      {s.content}
                    </p>
                    <div style={{ display: "flex", gap: "10px", fontSize: "11px", color: "#555" }}>
                      <span>👍 {s.upvotes?.length || 0}</span>
                      <span>👎 {s.downvotes?.length || 0}</span>
                      <span>{new Date(s.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {stats.stories === 0 && (
              <div style={{ textAlign: "center", padding: "20px", color: "#888", fontSize: "13px" }}>
                You haven't written any alternate endings yet.<br/>
                Click any movie to get started! 🎬
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
