import React, { useState, useEffect } from "react";
import MovieRow from "./MovieRow";
import StoryBox from "./StoryBox";

const genreClubs = [
  { name: "Action Club", genre: 28 },
  { name: "Sci-Fi Club", genre: 878 },
  { name: "Drama Club", genre: 18 },
  { name: "Comedy Club", genre: 35 },
  { name: "Thriller Club", genre: 53 }
];

function ClubCards({ movies, onSelect }) {
  const token = localStorage.getItem("token");
  const [selectedMovies, setSelectedMovies] = useState({});
  const [votes, setVotes] = useState({}); // { [genreId]: movieId } — the movie I voted for
  const [voteCounts, setVoteCounts] = useState({}); // { [genreId]: { [movieId]: count } }

  // Load existing votes when token is available
  useEffect(() => {
    if (!token) return;
    genreClubs.forEach(async c => {
      try {
        const res = await fetch(`http://localhost:5000/api/vote/${c.genre}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          if (data.myVote) {
            setVotes(prev => ({ ...prev, [c.genre]: data.myVote }));
          }
          if (data.counts) {
            setVoteCounts(prev => ({ ...prev, [c.genre]: data.counts }));
          }
        }
      } catch {}
    });
  }, [token]);

  async function handleVote(clubId) {
    const movie = selectedMovies[clubId];
    if (!token) { alert("Login required"); return; }
    if (!movie) { alert("Select a movie first"); return; }
    if (votes[clubId]) { alert("You already voted in this club"); return; }

    try {
      const res = await fetch("http://localhost:5000/api/vote", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ clubId, movieId: movie.id })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Vote failed");

      setVotes(prev => ({ ...prev, [clubId]: movie.id }));
      setVoteCounts(prev => ({
        ...prev,
        [clubId]: {
          ...(prev[clubId] || {}),
          [movie.id]: ((prev[clubId] || {})[movie.id] || 0) + 1
        }
      }));
      alert("Vote submitted!");
    } catch (err) {
      alert(err.message);
    }
  }

  return (
    <div>
      <h2>🎭 Genre Clubs</h2>

      {genreClubs.map((club, i) => {
        const clubMovies = Object.values(movies || {})
          .flat()
          .filter(m => m?.genre_ids?.includes(club.genre))
          .slice(0, 10);

        if (!clubMovies.length) return null;

        const selectedMovie = selectedMovies[club.genre];
        const votedMovieId = votes[club.genre];
        const counts = voteCounts[club.genre] || {};

        // Find the leading movie
        const leadingMovieId = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
        const totalVotes = Object.values(counts).reduce((s, n) => s + n, 0);

        return (
          <div key={i} className="section">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3>{club.name}</h3>
              {totalVotes > 0 && (
                <span style={{ fontSize: "12px", color: "gray" }}>
                  {totalVotes} {totalVotes === 1 ? "vote" : "votes"} cast
                </span>
              )}
            </div>

            {/* Movies row */}
            <MovieRow
              title=""
              movies={clubMovies}
              onSelect={(movie) => {
                onSelect(movie);
                if (!votedMovieId) {
                  setSelectedMovies(prev => ({ ...prev, [club.genre]: movie }));
                }
              }}
            />

            {/* Vote section */}
            {!votedMovieId && selectedMovie && (
              <div style={{ marginTop: "10px" }}>
                <p>Selected: <b>{selectedMovie.title}</b></p>
                <button onClick={() => handleVote(club.genre)}>
                  Vote for this movie
                </button>
              </div>
            )}

            {votedMovieId && (
              <div style={{ marginTop: "10px" }}>
                <p style={{ color: "lightgreen" }}>
                  ✅ You voted · {totalVotes > 0 && `${totalVotes} total votes`}
                </p>
                {leadingMovieId && counts[leadingMovieId] > 0 && (
                  <p style={{ fontSize: "13px", color: "gray" }}>
                    Leading: movie #{leadingMovieId} with {counts[leadingMovieId]} votes
                  </p>
                )}
              </div>
            )}

            {/* Alternate ending submission */}
            {token && votedMovieId && (
              <StoryBox
                clubId={club.genre}
                movieId={Number(votedMovieId)}
                token={token}
              />
            )}

            {!token && (
              <p style={{ fontSize: "12px", color: "gray", marginTop: "8px" }}>
                Login to vote and write alternate endings.
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default ClubCards;
