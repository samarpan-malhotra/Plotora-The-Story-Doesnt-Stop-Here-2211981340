import { useState, useEffect } from "react";

export default function Leaderboard() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState("score"); // "score" | "stories" | "upvotes"

  useEffect(() => { fetchLeaderboard(); }, []);

  async function fetchLeaderboard() {
    setLoading(true);
    try {
      // Single call gets ALL stories (club + direct movie submissions)
      const all = await fetch("http://localhost:5000/api/story/archive/all")
        .then(r => r.json()).then(d => Array.isArray(d) ? d : []).catch(() => []);

      // Aggregate by user
      const userMap = {};
      all.forEach(story => {
        const uid  = story.user?._id || story.user?.id || story.user || "unknown";
        const name = story.user?.name || "Anonymous";
        if (!userMap[uid]) userMap[uid] = { name, stories: 0, upvotes: 0, downvotes: 0 };
        userMap[uid].stories   += 1;
        userMap[uid].upvotes   += story.upvotes?.length || 0;
        userMap[uid].downvotes += story.downvotes?.length || 0;
      });

      // Score = participation (stories) + narrative quality (upvotes × 2)
      const sorted = Object.entries(userMap)
        .map(([uid, d]) => ({ uid, ...d, score: d.stories + d.upvotes * 2 }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 25);

      setEntries(sorted);
    } catch (e) { console.error(e); }
    setLoading(false);
  }

  const sorted = [...entries].sort((a, b) => b[sortBy] - a[sortBy]);
  const medals = ["🥇", "🥈", "🥉"];
  const medalColors = ["#FFD700", "#C0C0C0", "#CD7F32"];

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "6px" }}>
        <div>
          <h2 style={{ margin: "0 0 4px" }}>🏆 Leaderboard</h2>
          <p style={{ color: "#888", fontSize: "12px", margin: 0 }}>
            Score = endings written + (upvotes × 2) · reflects both participation & narrative quality
          </p>
        </div>
        <button onClick={fetchLeaderboard} style={{ fontSize: "12px", background: "rgba(255,255,255,0.07)", padding: "6px 12px" }}>↻ Refresh</button>
      </div>

      {/* Sort tabs */}
      <div style={{ display: "flex", gap: "6px", margin: "14px 0" }}>
        {[["score","🏆 Score"],["stories","✍️ Endings"],["upvotes","👍 Upvotes"]].map(([key, label]) => (
          <button key={key} onClick={() => setSortBy(key)} style={{
            fontSize: "12px", padding: "6px 14px",
            background: sortBy === key ? "rgba(99,102,241,0.7)" : "rgba(255,255,255,0.06)",
            border: "1px solid rgba(148,163,255,0.2)", borderRadius: "20px"
          }}>{label}</button>
        ))}
      </div>

      {loading && <p style={{ color: "#888" }}>Computing rankings...</p>}

      {!loading && sorted.length === 0 && (
        <p style={{ color: "#888" }}>No stories yet. Write the first alternate ending!</p>
      )}

      {sorted.map((entry, i) => (
        <div key={entry.uid} style={{
          display: "flex", alignItems: "center", gap: "14px",
          padding: "14px 16px", marginBottom: "8px", borderRadius: "14px",
          background: i === 0 ? "rgba(255,215,0,0.06)" : i === 1 ? "rgba(192,192,192,0.05)" : i === 2 ? "rgba(205,127,50,0.05)" : "rgba(255,255,255,0.03)",
          border: `1px solid ${i < 3 ? medalColors[i] + "33" : "rgba(148,163,255,0.08)"}`,
          transition: "transform 0.15s"
        }}>
          {/* Rank */}
          <div style={{ minWidth: "36px", textAlign: "center", fontSize: i < 3 ? "22px" : "15px", fontWeight: 700, color: i < 3 ? medalColors[i] : "#555" }}>
            {i < 3 ? medals[i] : `#${i + 1}`}
          </div>

          {/* Avatar */}
          <div style={{
            width: "38px", height: "38px", borderRadius: "50%", flexShrink: 0,
            background: `linear-gradient(135deg, hsl(${(i * 47) % 360},60%,55%), hsl(${(i * 47 + 60) % 360},70%,45%))`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: "15px", fontWeight: 800, color: "white"
          }}>
            {entry.name[0].toUpperCase()}
          </div>

          {/* Name + stats */}
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: "14px", marginBottom: "3px" }}>{entry.name}</div>
            <div style={{ fontSize: "11px", color: "#666", display: "flex", gap: "10px" }}>
              <span>✍️ {entry.stories} ending{entry.stories !== 1 ? "s" : ""}</span>
              <span>👍 {entry.upvotes}</span>
              <span>👎 {entry.downvotes}</span>
            </div>
          </div>

          {/* Score badge */}
          <div style={{
            background: i < 3 ? `${medalColors[i]}22` : "rgba(99,102,241,0.15)",
            border: `1px solid ${i < 3 ? medalColors[i] + "44" : "rgba(99,102,241,0.3)"}`,
            borderRadius: "10px", padding: "6px 12px", textAlign: "center"
          }}>
            <div style={{ fontSize: "16px", fontWeight: 800, color: i < 3 ? medalColors[i] : "#a5b4fc" }}>{entry.score}</div>
            <div style={{ fontSize: "9px", color: "#666" }}>SCORE</div>
          </div>
        </div>
      ))}
    </div>
  );
}
