import { useState, useEffect } from "react";

const WORD_LIMIT = 500;
const MIN_WORDS = 20;

function StoryBox({ clubId, movieId, token }) {
  const [text, setText] = useState("");
  const [msg, setMsg] = useState("");
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(false);

  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const isOverLimit = wordCount > WORD_LIMIT;
  const isTooShort = wordCount < MIN_WORDS;
  const canSubmit = !isOverLimit && !isTooShort && token;

  // Load existing stories for this club/movie
  useEffect(() => {
    if (!clubId) return;
    fetch(`http://localhost:5000/api/story/club/${clubId}`)
      .then(r => r.json())
      .then(data => setStories(Array.isArray(data) ? data : []))
      .catch(() => {});
  }, [clubId]);

  async function submitStory() {
    if (!canSubmit) return;
    setLoading(true);
    setMsg("");
    try {
      const res = await fetch("http://localhost:5000/api/story", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ clubId, movieId, content: text })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Submission failed");

      setMsg("✅ Alternate ending submitted!");
      setText("");
      // Add new story to list
      setStories(prev => [data.story, ...prev]);
    } catch (err) {
      setMsg("❌ " + err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <h3>✍️ Write Alternate Ending</h3>

      <textarea
        placeholder={`Write your alternate ending (${MIN_WORDS}–${WORD_LIMIT} words)...`}
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={6}
        style={{ width: "100%", boxSizing: "border-box" }}
      />

      <p style={{ color: isOverLimit ? "red" : wordCount >= MIN_WORDS ? "lightgreen" : "gray" }}>
        {wordCount} / {WORD_LIMIT} words
        {isTooShort && wordCount > 0 && ` (minimum ${MIN_WORDS} words)`}
      </p>

      <button disabled={!canSubmit || loading} onClick={submitStory}>
        {loading ? "Submitting..." : "Submit Ending"}
      </button>

      {!token && <p style={{ color: "orange" }}>Login to submit an ending.</p>}
      {msg && <p>{msg}</p>}

      {/* Show existing submissions */}
      {stories.length > 0 && (
        <div style={{ marginTop: "16px" }}>
          <h4>Community Endings ({stories.length})</h4>
          {stories.map((s, i) => (
            <div key={s._id || i} className="card" style={{ marginTop: "8px", opacity: 0.85 }}>
              <p style={{ fontSize: "12px", color: "gray", marginBottom: "4px" }}>
                by {s.user?.name || "Anonymous"} · {new Date(s.createdAt).toLocaleDateString()}
              </p>
              <p style={{ whiteSpace: "pre-wrap" }}>{s.content}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default StoryBox;