import { useEffect, useState } from "react";
import { tmdb } from "../api/tmdb";
import AlternateEndings from "./AlternateEndings";

export default function MovieModal({ movie, onClose, token }) {
  const [details, setDetails] = useState(null);
  const [cast, setCast] = useState([]);
  const [trailer, setTrailer] = useState(null);
  const [recs, setRecs] = useState([]);
  const [interested, setInterested] = useState(false);
  const [activeSection, setActiveSection] = useState("info"); // "info" | "endings"

  const type = movie?.media_type === "tv" || (!movie?.title && movie?.name) ? "tv" : "movie";

  useEffect(() => {
    if (!movie) return;
    setDetails(null); setRecs([]); setTrailer(null); setActiveSection("info");

    const saved = JSON.parse(localStorage.getItem("interested") || "[]");
    setInterested(saved.some(m => m.id === movie.id));

    async function load() {
      const [d, c, v, r] = await Promise.all([
        tmdb.details(movie.id, type),
        tmdb.credits(movie.id, type),
        tmdb.videos(movie.id, type),
        tmdb.recommendations(movie.id, type),
      ]);
      setDetails(d);
      setCast(c.cast?.slice(0, 8) || []);
      setTrailer(v.results?.find(x => x.type === "Trailer" && x.site === "YouTube"));
      setRecs(r.results?.filter(m => m.poster_path).slice(0, 12) || []);
    }
    load();
  }, [movie]);

  function toggleInterested() {
    const saved = JSON.parse(localStorage.getItem("interested") || "[]");
    const updated = interested
      ? saved.filter(m => m.id !== movie.id)
      : [{ id: movie.id, title: movie.title || movie.name, poster_path: movie.poster_path, media_type: type }, ...saved];
    localStorage.setItem("interested", JSON.stringify(updated));
    setInterested(!interested);
    // Notify App to refresh the watchlist row
    window.dispatchEvent(new CustomEvent("plotora:watchlist-update"));
    window.dispatchEvent(new CustomEvent("plotora:toast", {
      detail: { message: interested ? "Removed from watchlist" : "Added to watchlist! 🔖", type: "success" }
    }));
  }

  if (!movie) return null;

  const title       = details?.title || details?.name || movie.title || movie.name;
  const releaseDate = details?.release_date || details?.first_air_date;
  const rating      = details?.vote_average;
  const runtime     = details?.runtime ? `${details.runtime} min`
                    : details?.episode_run_time?.[0] ? `${details.episode_run_time[0]} min/ep` : null;
  const genres      = details?.genres?.map(g => g.name).join(" · ") || "";
  const seasons     = details?.number_of_seasons;

  const tabs = [
    { id: "info",    label: "ℹ️ Info" },
    { id: "endings", label: "✍️ Alternate Endings" },
  ];

  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0,
      background: "rgba(0,0,0,0.85)",
      zIndex: 1000, display: "flex",
      alignItems: "center", justifyContent: "center",
      padding: "20px", backdropFilter: "blur(4px)"
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background: "linear-gradient(160deg, #131929 0%, #0e1422 100%)",
        border: "1px solid rgba(148,163,255,0.15)",
        borderRadius: "20px", maxWidth: "780px", width: "100%",
        maxHeight: "88vh", overflowY: "auto", position: "relative",
      }}>

        {/* Close */}
        <button onClick={onClose} style={{
          position: "absolute", top: "14px", right: "14px",
          background: "rgba(255,255,255,0.1)", borderRadius: "50%",
          width: "32px", height: "32px", padding: 0,
          fontSize: "16px", zIndex: 10, lineHeight: "32px", textAlign: "center"
        }}>✕</button>

        {!details ? (
          <div style={{ padding: "60px", textAlign: "center", color: "#aaa" }}>Loading...</div>
        ) : (
          <>
            {/* Backdrop */}
            {details.backdrop_path && (
              <div style={{
                width: "100%", height: "190px",
                background: `linear-gradient(to bottom, rgba(13,18,34,0.2), #131929),
                             url(https://image.tmdb.org/t/p/w780${details.backdrop_path}) center/cover`,
                borderRadius: "20px 20px 0 0",
              }} />
            )}

            {/* Poster + info */}
            <div style={{ display: "flex", gap: "20px", padding: "0 22px 16px", marginTop: details.backdrop_path ? "-70px" : "22px" }}>
              <img
                src={`https://image.tmdb.org/t/p/w300${details.poster_path}`}
                alt={title}
                style={{
                  width: "130px", minWidth: "130px", height: "195px",
                  objectFit: "cover", borderRadius: "12px",
                  boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
                  border: "2px solid rgba(148,163,255,0.2)", alignSelf: "flex-end"
                }}
              />
              <div style={{ flex: 1, minWidth: 0, paddingTop: details.backdrop_path ? "80px" : "0" }}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "8px" }}>
                  <h2 style={{ margin: "0 0 6px", fontSize: "20px", lineHeight: 1.3 }}>{title}</h2>
                  {type === "tv" && (
                    <span style={{ background: "rgba(99,102,241,0.3)", color: "#a5b4fc", fontSize: "11px", padding: "3px 8px", borderRadius: "20px", whiteSpace: "nowrap", border: "1px solid rgba(99,102,241,0.4)" }}>TV</span>
                  )}
                </div>
                <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", marginBottom: "8px", alignItems: "center" }}>
                  {rating > 0 && <span style={{ color: "#f5c518", fontWeight: 700 }}>⭐ {rating.toFixed(1)}</span>}
                  {releaseDate && <span style={{ color: "#888", fontSize: "13px" }}>📅 {releaseDate.slice(0, 4)}</span>}
                  {runtime && <span style={{ color: "#888", fontSize: "13px" }}>⏱ {runtime}</span>}
                  {seasons && <span style={{ color: "#888", fontSize: "13px" }}>📺 {seasons} Season{seasons > 1 ? "s" : ""}</span>}
                </div>
                {genres && <p style={{ color: "#a5b4fc", fontSize: "12px", margin: "0 0 8px" }}>{genres}</p>}
                <p style={{ color: "#bbb", fontSize: "13px", lineHeight: 1.7, margin: "0 0 12px" }}>
                  {details.overview || "No overview available."}
                </p>
                <button onClick={toggleInterested} style={{
                  background: interested ? "rgba(99,102,241,0.8)" : "rgba(255,255,255,0.08)",
                  border: "1px solid rgba(148,163,255,0.3)", borderRadius: "10px",
                  padding: "7px 14px", fontSize: "13px", fontWeight: 600
                }}>
                  {interested ? "✅ In Watchlist" : "🔖 Add to Watchlist"}
                </button>
              </div>
            </div>

            {/* Tab switcher */}
            <div style={{ display: "flex", gap: "4px", padding: "0 22px 0", borderBottom: "1px solid rgba(148,163,255,0.1)", marginBottom: "0" }}>
              {tabs.map(tab => (
                <button key={tab.id} onClick={() => setActiveSection(tab.id)} style={{
                  background: "none", border: "none", padding: "10px 16px",
                  fontSize: "13px", fontWeight: 600, cursor: "pointer",
                  color: activeSection === tab.id ? "#a5b4fc" : "#555",
                  borderBottom: activeSection === tab.id ? "2px solid #6366f1" : "2px solid transparent",
                  borderRadius: 0, transition: "all 0.2s"
                }}>
                  {tab.label}
                </button>
              ))}
            </div>

            <div style={{ padding: "18px 22px 22px", display: "flex", flexDirection: "column", gap: "18px" }}>

              {/* INFO TAB */}
              {activeSection === "info" && (
                <>
                  {trailer && (
                    <div>
                      <h3 style={{ margin: "0 0 10px", fontSize: "14px", color: "#e2e8f0" }}>🎬 Trailer</h3>
                      <iframe width="100%" height="195"
                        src={`https://www.youtube.com/embed/${trailer.key}`}
                        title="trailer"
                        style={{ borderRadius: "10px", border: "none", display: "block" }}
                        allowFullScreen
                      />
                    </div>
                  )}

                  {cast.length > 0 && (
                    <div>
                      <h3 style={{ margin: "0 0 10px", fontSize: "14px", color: "#e2e8f0" }}>👥 Cast</h3>
                      <div style={{ display: "flex", gap: "10px", overflowX: "auto", paddingBottom: "4px" }}>
                        {cast.map(a => (
                          <div key={a.id} style={{ textAlign: "center", minWidth: "66px" }}>
                            <img
                              src={a.profile_path ? `https://image.tmdb.org/t/p/w185${a.profile_path}` : "https://via.placeholder.com/60x60?text=?"}
                              alt={a.name}
                              style={{ width: "56px", height: "56px", borderRadius: "50%", objectFit: "cover", border: "2px solid rgba(148,163,255,0.2)" }}
                            />
                            <p style={{ fontSize: "9px", color: "#aaa", margin: "4px 0 0", lineHeight: 1.3 }}>{a.name}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {recs.length > 0 && (
                    <div>
                      <h3 style={{ margin: "0 0 10px", fontSize: "14px", color: "#e2e8f0" }}>🎯 You Might Also Like</h3>
                      <div style={{ display: "flex", gap: "10px", overflowX: "auto", paddingBottom: "4px" }}>
                        {recs.map(m => (
                          <div key={m.id}
                            onClick={() => window.dispatchEvent(new CustomEvent("plotora:select", { detail: m }))}
                            style={{ minWidth: "88px", cursor: "pointer" }}
                          >
                            <img
                              src={`https://image.tmdb.org/t/p/w200${m.poster_path}`}
                              alt={m.title || m.name}
                              style={{ width: "88px", height: "126px", objectFit: "cover", borderRadius: "8px", display: "block", transition: "transform 0.2s" }}
                              onMouseEnter={e => e.target.style.transform = "scale(1.05)"}
                              onMouseLeave={e => e.target.style.transform = "scale(1)"}
                            />
                            <p style={{ fontSize: "9px", color: "#aaa", margin: "4px 0 0", textAlign: "center", lineHeight: 1.3, width: "88px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                              {m.title || m.name}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* ALTERNATE ENDINGS TAB */}
              {activeSection === "endings" && (
                <AlternateEndings
                  movieId={movie.id}
                  movieTitle={title}
                  token={token}
                />
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
