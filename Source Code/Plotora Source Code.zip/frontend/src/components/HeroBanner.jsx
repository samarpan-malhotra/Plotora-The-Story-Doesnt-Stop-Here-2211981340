import { useState, useEffect } from "react";

export default function HeroBanner({ movies, onSelect }) {
  const [idx, setIdx] = useState(0);
  const featured = movies?.filter(m => m.backdrop_path).slice(0, 5) || [];

  useEffect(() => {
    if (!featured.length) return;
    const t = setInterval(() => setIdx(i => (i + 1) % featured.length), 6000);
    return () => clearInterval(t);
  }, [featured.length]);

  if (!featured.length) return null;

  const movie = featured[idx];

  return (
    <div style={{
      position: "relative", borderRadius: "20px", overflow: "hidden",
      height: "340px", marginBottom: "32px", cursor: "pointer"
    }} onClick={() => onSelect(movie)}>

      {/* Backdrop */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `url(https://image.tmdb.org/t/p/w1280${movie.backdrop_path})`,
        backgroundSize: "cover", backgroundPosition: "center",
        transition: "opacity 0.8s ease",
      }}/>

      {/* Gradient overlays */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to right, rgba(11,16,32,0.95) 35%, rgba(11,16,32,0.3) 100%)" }}/>
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(11,16,32,0.8) 0%, transparent 60%)" }}/>

      {/* Content */}
      <div style={{ position: "relative", padding: "40px", height: "100%", display: "flex", flexDirection: "column", justifyContent: "center", maxWidth: "55%" }}>
        <div style={{ display: "flex", gap: "8px", marginBottom: "12px", flexWrap: "wrap" }}>
          <span style={{ background: "rgba(99,102,241,0.3)", border: "1px solid rgba(99,102,241,0.5)", color: "#a5b4fc", fontSize: "11px", padding: "3px 10px", borderRadius: "20px", fontWeight: 600 }}>
            🔥 FEATURED
          </span>
          {movie.vote_average > 0 && (
            <span style={{ background: "rgba(245,197,24,0.15)", border: "1px solid rgba(245,197,24,0.3)", color: "#f5c518", fontSize: "11px", padding: "3px 10px", borderRadius: "20px", fontWeight: 700 }}>
              ⭐ {movie.vote_average.toFixed(1)}
            </span>
          )}
        </div>

        <h2 style={{ margin: "0 0 10px", fontSize: "32px", fontWeight: 800, lineHeight: 1.2, color: "#fff", textShadow: "0 2px 8px rgba(0,0,0,0.5)" }}>
          {movie.title || movie.name}
        </h2>

        <p style={{ color: "#bbb", fontSize: "13px", lineHeight: 1.6, margin: "0 0 20px", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
          {movie.overview}
        </p>

        <div style={{ display: "flex", gap: "10px" }}>
          <button style={{ background: "rgba(99,102,241,0.9)", padding: "10px 22px", borderRadius: "12px", fontSize: "14px", fontWeight: 700 }}>
            ▶ View Details
          </button>
          <button
            onClick={e => { e.stopPropagation(); window.dispatchEvent(new CustomEvent("plotora:toast", { detail: { message: "Added to watchlist!", type: "success" } })); }}
            style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)", padding: "10px 22px", borderRadius: "12px", fontSize: "14px" }}>
            🔖 Watchlist
          </button>
        </div>
      </div>

      {/* Dot indicators */}
      <div style={{ position: "absolute", bottom: "16px", right: "20px", display: "flex", gap: "6px" }}>
        {featured.map((_, i) => (
          <div key={i} onClick={e => { e.stopPropagation(); setIdx(i); }} style={{
            width: i === idx ? "20px" : "6px", height: "6px",
            borderRadius: "3px", background: i === idx ? "#6366f1" : "rgba(255,255,255,0.3)",
            cursor: "pointer", transition: "all 0.3s"
          }}/>
        ))}
      </div>
    </div>
  );
}
