export default function Logo({ size = 28 }) {
  return (
    <svg width={size * 3.2} height={size} viewBox="0 0 192 60" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="filmGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#818cf8"/>
          <stop offset="100%" stopColor="#a78bfa"/>
        </linearGradient>
        <linearGradient id="textGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#e0e7ff"/>
          <stop offset="100%" stopColor="#a5b4fc"/>
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="1.5" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>

      {/* Film reel icon */}
      <g filter="url(#glow)">
        {/* Outer circle */}
        <circle cx="30" cy="30" r="26" stroke="url(#filmGrad)" strokeWidth="2.5" fill="rgba(99,102,241,0.12)"/>
        {/* Center hole */}
        <circle cx="30" cy="30" r="7" fill="url(#filmGrad)" opacity="0.9"/>
        <circle cx="30" cy="30" r="3.5" fill="#0b1020"/>
        {/* Film sprocket holes - outer ring */}
        {[0,60,120,180,240,300].map((deg, i) => {
          const rad = (deg * Math.PI) / 180;
          const x = 30 + 17 * Math.cos(rad);
          const y = 30 + 17 * Math.sin(rad);
          return <circle key={i} cx={x} cy={y} r="3.2" fill="url(#filmGrad)" opacity="0.85"/>;
        })}
        {/* Pen/story nib at bottom-right */}
        <path d="M49 45 L56 52 L52 56 L45 49 Z" fill="url(#filmGrad)" opacity="0.95"/>
        <path d="M52 56 L50 60 L56 58 Z" fill="#a5b4fc"/>
        <line x1="46" y1="47" x2="54" y2="55" stroke="#0b1020" strokeWidth="1.2"/>
      </g>

      {/* Plotora text */}
      <text
        x="66"
        y="38"
        fontFamily="'Inter', 'Segoe UI', system-ui, sans-serif"
        fontWeight="800"
        fontSize="26"
        letterSpacing="-0.5"
        fill="url(#textGrad)"
      >
        Plotora
      </text>

      {/* Tagline */}
      <text
        x="67"
        y="51"
        fontFamily="'Inter', system-ui, sans-serif"
        fontWeight="400"
        fontSize="8.5"
        letterSpacing="2.5"
        fill="#6366f1"
        opacity="0.9"
      >
        THE STORY DOESN'T STOP HERE
      </text>
    </svg>
  );
}
