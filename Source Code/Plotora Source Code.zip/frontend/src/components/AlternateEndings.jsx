import { useState, useEffect } from "react";
import { showToast } from "./Toast";

const WORD_LIMIT = 500;
const WORD_MIN = 20;

export default function AlternateEndings({ movieId, movieTitle, token }) {
  const [stories, setStories] = useState([]);
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState("newest");
  const [voteState, setVoteState] = useState({});
  const [hoveredBtn, setHoveredBtn] = useState(null); // "up-storyId" | "down-storyId"

  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const isOverLimit = wordCount > WORD_LIMIT;
  const canSubmit = !isOverLimit && wordCount >= WORD_MIN && token && !submitting;

  useEffect(() => { if (movieId) fetchStories(); }, [movieId]);

  function getUserId() {
    try { const u = JSON.parse(localStorage.getItem("user") || "null"); return u?._id || u?.id || ""; }
    catch { return ""; }
  }

  async function fetchStories() {
    setLoading(true);
    try {
      const res = await fetch(`http://localhost:5000/api/story/movie/${movieId}`);
      const data = await res.json();
      const list = Array.isArray(data) ? data : [];
      setStories(list);
      const userId = getUserId();
      const vs = {};
      list.forEach(s => {
        const upArr   = Array.isArray(s.upvotes)   ? s.upvotes   : [];
        const dnArr   = Array.isArray(s.downvotes)  ? s.downvotes : [];
        vs[s._id] = {
          upvotes:   upArr.length,
          downvotes: dnArr.length,
          userVote:  upArr.some(id => id?.toString() === userId) ? "up"
                   : dnArr.some(id => id?.toString() === userId) ? "down" : null
        };
      });
      setVoteState(vs);
    } catch { }
    setLoading(false);
  }

  async function submitStory() {
    if (!canSubmit) return;
    setSubmitting(true);
    try {
      const res = await fetch("http://localhost:5000/api/story", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ movieId, content: text })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed");
      setStories(prev => [data.story, ...prev]);
      setVoteState(prev => ({ ...prev, [data.story._id]: { upvotes: 0, downvotes: 0, userVote: null } }));
      setText(""); setShowForm(false);
      showToast("Your alternate ending was posted!");
    } catch (err) { showToast(err.message, "error"); }
    setSubmitting(false);
  }

  async function deleteStory(storyId) {
    if (!window.confirm("Delete this alternate ending? This cannot be undone.")) return;
    try {
      const res = await fetch(`http://localhost:5000/api/story/${storyId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setStories(prev => prev.filter(s => s._id !== storyId));
      showToast("Ending deleted");
    } catch (err) { showToast(err.message, "error"); }
  }

  async function vote(storyId, type) {
    if (!token) { showToast("Please login to vote", "warning"); return; }
    try {
      const res = await fetch(`http://localhost:5000/api/story/${storyId}/vote`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ type })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setVoteState(prev => ({ ...prev, [storyId]: data }));
      showToast(type === "up" ? "Upvoted! 👍" : "Downvoted 👎");
    } catch (err) { showToast(err.message, "error"); }
  }

  const sorted = [...stories].sort((a, b) => {
    if (sortBy === "top") {
      const aScore = (voteState[a._id]?.upvotes || 0) - (voteState[a._id]?.downvotes || 0);
      const bScore = (voteState[b._id]?.upvotes || 0) - (voteState[b._id]?.downvotes || 0);
      return bScore - aScore;
    }
    return new Date(b.createdAt) - new Date(a.createdAt);
  });

  const wordColor = isOverLimit ? "#f87171" : wordCount >= WORD_MIN ? "#4ade80" : "#888";

  return (
    <div>
      <style>{`
        .vote-btn {
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 10px 20px;
          border-radius: 24px;
          font-size: 15px;
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.18s cubic-bezier(.34,1.56,.64,1), box-shadow 0.18s, background 0.15s;
          border: 2px solid;
          min-width: 80px;
          justify-content: center;
          user-select: none;
        }
        .vote-btn:hover {
          transform: scale(1.18) translateY(-2px);
          box-shadow: 0 6px 20px rgba(0,0,0,0.35);
        }
        .vote-btn:active {
          transform: scale(0.95);
        }
        .vote-btn.up {
          background: rgba(74,222,128,0.12);
          border-color: rgba(74,222,128,0.3);
          color: #6ee7a0;
        }
        .vote-btn.up.active, .vote-btn.up:hover {
          background: rgba(74,222,128,0.22);
          border-color: #4ade80;
          color: #4ade80;
        }
        .vote-btn.down {
          background: rgba(248,113,113,0.10);
          border-color: rgba(248,113,113,0.25);
          color: #fca5a5;
        }
        .vote-btn.down.active, .vote-btn.down:hover {
          background: rgba(248,113,113,0.22);
          border-color: #f87171;
          color: #f87171;
        }
      `}</style>

      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "14px", flexWrap: "wrap", gap: "8px" }}>
        <h3 style={{ margin: 0, fontSize: "15px", color: "#e2e8f0" }}>
          ✍️ Alternate Endings
          {stories.length > 0 && <span style={{ color: "#888", fontWeight: 400, marginLeft: "6px" }}>({stories.length})</span>}
        </h3>
        <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
          {stories.length > 1 && (
            <div style={{ display: "flex", gap: "4px" }}>
              {[["newest","🕐 New"],["top","🔥 Top"]].map(([k,l]) => (
                <button key={k} onClick={() => setSortBy(k)} style={{
                  fontSize: "11px", padding: "5px 12px", borderRadius: "20px",
                  background: sortBy === k ? "rgba(99,102,241,0.6)" : "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(148,163,255,0.2)"
                }}>{l}</button>
              ))}
            </div>
          )}
          {token ? (
            <button onClick={() => setShowForm(f => !f)} style={{
              fontSize: "12px", padding: "7px 16px",
              background: showForm ? "rgba(255,255,255,0.06)" : "rgba(99,102,241,0.7)",
              border: "1px solid rgba(148,163,255,0.3)", borderRadius: "20px", fontWeight: 600
            }}>
              {showForm ? "✕ Cancel" : "+ Write Ending"}
            </button>
          ) : (
            <span style={{ fontSize: "12px", color: "#555" }}>Login to write</span>
          )}
        </div>
      </div>

      {/* Write form */}
      {showForm && (
        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(148,163,255,0.15)", borderRadius: "14px", padding: "16px", marginBottom: "16px" }}>
          <p style={{ fontSize: "12px", color: "#a5b4fc", margin: "0 0 10px" }}>
            How would <strong>you</strong> end <em>{movieTitle}</em>? ({WORD_MIN}–{WORD_LIMIT} words)
          </p>
          <textarea
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder="Write your alternate ending..."
            rows={5}
            style={{ width: "100%", boxSizing: "border-box", padding: "10px", background: "#0a0f1e", border: "1px solid rgba(148,163,255,0.2)", borderRadius: "10px", color: "white", fontSize: "13px", fontFamily: "inherit", resize: "vertical" }}
          />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "8px", gap: "10px", flexWrap: "wrap" }}>
            <span style={{ fontSize: "12px", color: wordColor }}>
              {wordCount} / {WORD_LIMIT} words
              {wordCount > 0 && wordCount < WORD_MIN && ` · ${WORD_MIN - wordCount} more needed`}
            </span>
            <div style={{ width: "100px", height: "4px", background: "rgba(255,255,255,0.1)", borderRadius: "2px", overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${Math.min((wordCount / WORD_LIMIT) * 100, 100)}%`, background: isOverLimit ? "#f87171" : wordCount >= WORD_MIN ? "#4ade80" : "#6366f1", borderRadius: "2px", transition: "width 0.2s" }}/>
            </div>
            <button onClick={submitStory} disabled={!canSubmit} style={{ padding: "8px 20px", fontSize: "13px", fontWeight: 700, borderRadius: "10px", opacity: canSubmit ? 1 : 0.4 }}>
              {submitting ? "Posting..." : "Post Ending"}
            </button>
          </div>
        </div>
      )}

      {/* Stories list */}
      {loading && <p style={{ color: "#888", fontSize: "13px", textAlign: "center", padding: "20px" }}>Loading endings...</p>}

      {!loading && sorted.length === 0 && (
        <div style={{ textAlign: "center", padding: "32px", background: "rgba(255,255,255,0.02)", borderRadius: "14px", border: "1px dashed rgba(148,163,255,0.12)" }}>
          <div style={{ fontSize: "36px", marginBottom: "10px" }}>📝</div>
          <p style={{ color: "#888", fontSize: "13px", margin: 0 }}>
            {token ? "Be the first to write an alternate ending for this movie!" : "Login to write the first alternate ending!"}
          </p>
        </div>
      )}

      {sorted.map((story, idx) => {
        const vs = voteState[story._id] || { upvotes: story.upvotes?.length || 0, downvotes: story.downvotes?.length || 0, userVote: null };
        const score = vs.upvotes - vs.downvotes;

        return (
          <div key={story._id} style={{
            background: "rgba(255,255,255,0.03)",
            border: `1px solid ${idx === 0 && sortBy === "top" && sorted.length > 1 ? "rgba(99,102,241,0.3)" : "rgba(148,163,255,0.08)"}`,
            borderRadius: "16px", padding: "18px", marginBottom: "12px"
          }}>
            {/* Top badge */}
            {idx === 0 && sortBy === "top" && sorted.length > 1 && (
              <span style={{ fontSize: "10px", background: "rgba(99,102,241,0.2)", color: "#a5b4fc", padding: "3px 10px", borderRadius: "20px", border: "1px solid rgba(99,102,241,0.3)", display: "inline-block", marginBottom: "10px" }}>
                🔥 Community Favourite
              </span>
            )}

            {/* Author */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "9px" }}>
                <div style={{
                  width: "34px", height: "34px", borderRadius: "50%", flexShrink: 0,
                  background: `linear-gradient(135deg, hsl(${(story.user?.name?.charCodeAt(0) || 65) * 5 % 360},65%,52%), hsl(${(story.user?.name?.charCodeAt(0) || 65) * 9 % 360},70%,38%))`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: "14px", fontWeight: 800, color: "white"
                }}>
                  {(story.user?.name || "A")[0].toUpperCase()}
                </div>
                <div>
                  <div style={{ fontSize: "13px", fontWeight: 700, color: "#c7d2fe" }}>{story.user?.name || "Anonymous"}</div>
                  <div style={{ fontSize: "10px", color: "#444" }}>
                    {new Date(story.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </div>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <span style={{ fontSize: "11px", color: "#444", background: "rgba(255,255,255,0.04)", padding: "3px 8px", borderRadius: "8px" }}>
                  {story.content?.trim().split(/\s+/).length} words
                </span>
                {/* Delete button — only for the author */}
                {getUserId() && (story.user?._id || story.user?.id || story.user)?.toString() === getUserId() && (
                  <button
                    onClick={() => deleteStory(story._id)}
                    title="Delete your ending"
                    style={{
                      background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.25)",
                      color: "#fca5a5", borderRadius: "8px", padding: "4px 10px",
                      fontSize: "12px", cursor: "pointer", transition: "all 0.2s"
                    }}
                    onMouseEnter={e => { e.target.style.background = "rgba(239,68,68,0.25)"; e.target.style.borderColor = "#ef4444"; }}
                    onMouseLeave={e => { e.target.style.background = "rgba(239,68,68,0.1)"; e.target.style.borderColor = "rgba(239,68,68,0.25)"; }}
                  >
                    🗑 Delete
                  </button>
                )}
              </div>
            </div>

            {/* Content */}
            <p style={{ fontSize: "13px", color: "#c4c9e2", lineHeight: 1.8, margin: "0 0 16px", whiteSpace: "pre-wrap" }}>
              {story.content}
            </p>

            {/* Vote row */}
            <div style={{ display: "flex", alignItems: "center", gap: "12px", paddingTop: "4px", borderTop: "1px solid rgba(148,163,255,0.06)" }}>
              <button
                className={`vote-btn up ${vs.userVote === "up" ? "active" : ""}`}
                onClick={() => vote(story._id, "up")}
              >
                👍 <span style={{ fontSize: "16px" }}>{vs.upvotes}</span>
              </button>

              <button
                className={`vote-btn down ${vs.userVote === "down" ? "active" : ""}`}
                onClick={() => vote(story._id, "down")}
              >
                👎 <span style={{ fontSize: "16px" }}>{vs.downvotes}</span>
              </button>

              <div style={{ marginLeft: "4px", display: "flex", alignItems: "center", gap: "4px" }}>
                <span style={{ fontSize: "14px", fontWeight: 800, color: score > 0 ? "#4ade80" : score < 0 ? "#f87171" : "#555" }}>
                  {score > 0 ? `+${score}` : score}
                </span>
                <span style={{ fontSize: "11px", color: "#555" }}>pts</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
