import { useState } from "react";
import { api } from "../api/api";

export default function LoginModal({ onClose, onLogin }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit() {
    setLoading(true);
    setMsg("");
    try {
      const res = mode === "login" ? await api.login(form) : await api.register(form);
      localStorage.setItem("token", res.token);
      onLogin(res.token, res.user);
      // onLogin in App.jsx already closes the modal + redirects
    } catch {
      setMsg(mode === "login" ? "Invalid email or password." : "Registration failed. Try again.");
    } finally {
      setLoading(false);
    }
  }

  function handleKey(e) {
    if (e.key === "Enter") handleSubmit();
  }

  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0,
      background: "rgba(0,0,0,0.8)",
      zIndex: 2000,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      backdropFilter: "blur(6px)"
    }}>
      <div onClick={e => e.stopPropagation()} style={{
        background: "linear-gradient(160deg, #131929, #0e1422)",
        border: "1px solid rgba(148,163,255,0.2)",
        borderRadius: "20px",
        padding: "36px",
        width: "100%",
        maxWidth: "380px",
        position: "relative",
        boxShadow: "0 24px 64px rgba(0,0,0,0.7)"
      }}>

        {/* Close */}
        <button onClick={onClose} style={{
          position: "absolute", top: "14px", right: "14px",
          background: "rgba(255,255,255,0.08)", borderRadius: "50%",
          width: "30px", height: "30px", padding: 0, fontSize: "14px"
        }}>✕</button>

        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: "24px" }}>
          <div style={{ fontSize: "32px", marginBottom: "6px" }}>🎬</div>
          <h2 style={{ margin: 0, fontSize: "22px" }}>{mode === "login" ? "Welcome back" : "Join Plotora"}</h2>
          <p style={{ color: "#888", fontSize: "13px", margin: "6px 0 0" }}>
            {mode === "login" ? "Sign in to vote & write alternate endings" : "Create an account to get started"}
          </p>
        </div>

        {mode === "register" && (
          <input
            placeholder="Your name"
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
            onKeyDown={handleKey}
            style={{ marginBottom: "10px" }}
          />
        )}

        <input
          placeholder="Email address"
          type="email"
          value={form.email}
          onChange={e => setForm({ ...form, email: e.target.value })}
          onKeyDown={handleKey}
          style={{ marginBottom: "10px" }}
        />

        <input
          placeholder="Password"
          type="password"
          value={form.password}
          onChange={e => setForm({ ...form, password: e.target.value })}
          onKeyDown={handleKey}
          style={{ marginBottom: "16px" }}
        />

        <button
          onClick={handleSubmit}
          disabled={loading}
          style={{ width: "100%", padding: "12px", fontSize: "15px", fontWeight: 600, borderRadius: "12px" }}
        >
          {loading ? "Please wait..." : mode === "login" ? "Sign In" : "Create Account"}
        </button>

        {msg && <p style={{ color: "#f87171", fontSize: "13px", marginTop: "10px", textAlign: "center" }}>{msg}</p>}

        <p
          style={{ textAlign: "center", color: "#6366f1", cursor: "pointer", fontSize: "13px", marginTop: "16px" }}
          onClick={() => { setMode(mode === "login" ? "register" : "login"); setMsg(""); }}
        >
          {mode === "login" ? "Don't have an account? Register" : "Already have an account? Sign in"}
        </p>
      </div>
    </div>
  );
}
