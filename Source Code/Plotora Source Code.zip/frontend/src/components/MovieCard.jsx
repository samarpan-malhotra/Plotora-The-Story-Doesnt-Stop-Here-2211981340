export default function MovieCard({ movie, onClick }) {
  const title = movie.title || movie.name;
  const poster = movie.poster_path
    ? `https://image.tmdb.org/t/p/w300${movie.poster_path}`
    : "https://via.placeholder.com/300x450?text=No+Image";

  const rating = movie.vote_average?.toFixed(1);

  return (
    <div className="movie-card" onClick={() => onClick(movie)}>
      <img src={poster} alt={title} loading="lazy" />
      <div className="movie-card-info">
        <p className="movie-card-title">{title}</p>
        {rating > 0 && <span className="movie-card-rating">⭐ {rating}</span>}
      </div>
    </div>
  );
}
