import { useRef } from "react";
import MovieCard from "./MovieCard";

export default function MovieRow({ title, movies, onSelect }) {
  const ref = useRef();

  const scroll = (dir) => {
    ref.current.scrollBy({ left: dir * 800, behavior: "smooth" });
  };

  return (
    <div className="section">
      <h2>{title}</h2>

      <button className="scroll-btn left" onClick={() => scroll(-1)}>❮</button>
      <button className="scroll-btn right" onClick={() => scroll(1)}>❯</button>

      <div ref={ref} className="row-scroll">
        {movies.map(m => (
          <MovieCard key={m.id} movie={m} onClick={onSelect} />
        ))}
      </div>
    </div>
  );
}