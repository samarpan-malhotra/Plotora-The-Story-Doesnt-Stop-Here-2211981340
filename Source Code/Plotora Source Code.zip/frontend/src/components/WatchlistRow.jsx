import { useRef, useState } from "react";

export default function WatchlistRow({ onSelect, onUpdate }) {
  const ref = useRef();
  const [list, setList] = useState(() => {
    try { return JSON.parse(localStorage.getItem("interested") || "[]"); } catch { return []; }
  });

  function removeFromWatchlist(e, movieId) {
    e.stopPropagation(); // don't open modal
    const updated = list.filter(m => m.id !== movieId);
    setList(updated);
    localStorage.setItem("interested", JSON.stringify(updated));
    if (onUpdate) onUpdate(updated);
  }

  const scroll = dir => ref.current?.scrollBy({ left: dir * 700, behavior: "smooth" });

  if (!list.length) return null;

  return (
    <div className="section">
      <h2>🔖 Your Watchlist <span style={{ fontSize: "13px", color: "#555", fontWeight: 400 }}>({list.length})</span></h2>

      <button className="scroll-btn left" onClick={() => scroll(-1)}>❮</button>
      <button className="scroll-btn right" onClick={() => scroll(1)}>❯</button>

      <div ref={ref} className="row-scroll">
        {list.map(m => (
          <div key={m.id} style={{ position: "relative", flexShrink: 0 }}>
            {/* Movie card */}
            <div
              className="movie-card"
              onClick={() => onSelect(m)}
            >
              <img
                src={m.poster_path
                  ? `https://image.tmdb.org/t/p/w300${m.poster_path}`
                  : "https://via.placeholder.com/130x195?text=No+Image"}
                alt={m.title || m.name}
                loading="lazy"
              />
              <div className="movie-card-info">
                <p className="movie-card-title">{m.title || m.name}</p>
                {m.media_type === "tv" && (
                  <span style={{ fontSize: "9px", color: "#6366f1", fontWeight: 700 }}>TV</span>
                )}
              </div>
            </div>

            {/* Remove button — top-right corner of card */}
            <button
              onClick={(e) => removeFromWatchlist(e, m.id)}
              title="Remove from watchlist"
              style={{
                position: "absolute", top: "6px", right: "6px",
                width: "24px", height: "24px", borderRadius: "50%",
                background: "rgba(0,0,0,0.75)", border: "1px solid rgba(255,255,255,0.15)",
                color: "#fca5a5", fontSize: "12px", padding: 0,
                display: "flex", alignItems: "center", justifyContent: "center",
                cursor: "pointer", zIndex: 10,
                transition: "all 0.2s", lineHeight: 1
              }}
              onMouseEnter={e => { e.currentTarget.style.background = "rgba(239,68,68,0.85)"; e.currentTarget.style.color = "white"; e.currentTarget.style.transform = "scale(1.15)"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "rgba(0,0,0,0.75)"; e.currentTarget.style.color = "#fca5a5"; e.currentTarget.style.transform = "scale(1)"; }}
            >
              ✕
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
