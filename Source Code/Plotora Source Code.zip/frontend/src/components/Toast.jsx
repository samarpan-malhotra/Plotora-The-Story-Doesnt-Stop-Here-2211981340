import { useEffect, useState } from "react";

// Global toast event system
export function showToast(message, type = "success") {
  window.dispatchEvent(new CustomEvent("plotora:toast", { detail: { message, type } }));
}

export default function ToastContainer() {
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    const handler = (e) => {
      const id = Date.now();
      setToasts(prev => [...prev, { ...e.detail, id }]);
      setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3500);
    };
    window.addEventListener("plotora:toast", handler);
    return () => window.removeEventListener("plotora:toast", handler);
  }, []);

  if (!toasts.length) return null;

  return (
    <div style={{ position: "fixed", bottom: "24px", right: "24px", zIndex: 9999, display: "flex", flexDirection: "column", gap: "8px" }}>
      {toasts.map(t => (
        <div key={t.id} style={{
          background: t.type === "error" ? "rgba(239,68,68,0.15)" : t.type === "warning" ? "rgba(245,158,11,0.15)" : "rgba(74,222,128,0.15)",
          border: `1px solid ${t.type === "error" ? "rgba(239,68,68,0.4)" : t.type === "warning" ? "rgba(245,158,11,0.4)" : "rgba(74,222,128,0.4)"}`,
          color: t.type === "error" ? "#fca5a5" : t.type === "warning" ? "#fcd34d" : "#86efac",
          padding: "12px 18px", borderRadius: "12px", fontSize: "13px", fontWeight: 500,
          backdropFilter: "blur(12px)", boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
          animation: "slideIn 0.3s ease",
          maxWidth: "300px"
        }}>
          {t.type === "error" ? "❌ " : t.type === "warning" ? "⚠️ " : "✅ "}{t.message}
        </div>
      ))}
      <style>{`@keyframes slideIn { from { opacity:0; transform:translateX(20px); } to { opacity:1; transform:translateX(0); } }`}</style>
    </div>
  );
}
