export default function SearchBar({ value, onChange }) {
  return (
    <input
      type="text"
      placeholder="Search ANY movie..."
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{ marginBottom: "20px" }}
    />
  );
}