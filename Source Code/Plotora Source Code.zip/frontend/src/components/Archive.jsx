import { useState, useEffect } from "react";

function Archive() {
  const [archive, setArchive] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all"); // "all" | "club" | "direct"
  const [expanded, setExpanded] = useState(null);
  const [sortBy, setSortBy] = useState("newest"); // "newest" | "top"

  useEffect(() => { fetchArchive(); }, []);

  async function fetchArchive() {
    setLoading(true);
    try {
      const res = await fetch("http://localhost:5000/api/story/archive/all");
      const data = await res.json();
      setArchive(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Archive fetch error:", err);
    } finally {
      setLoading(false);
    }
  }

  const filtered = archive.filter(s => {
    if (filter === "club") return s.club && s.club !== 0;
    if (filter === "direct") return !s.club || s.club === 0;
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === "top") {
      const aScore = (a.upvotes?.length || 0) - (a.downvotes?.length || 0);
      const bScore = (b.upvotes?.length || 0) - (b.downvotes?.length || 0);
      return bScore - aScore;
    }
    return new Date(b.createdAt) - new Date(a.createdAt);
  });

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: "20px" }}>
        <h2 style={{ margin: "0 0 6px" }}>📚 Archive</h2>
        <p style={{ color: "#888", fontSize: "13px", margin: 0 }}>
          Every alternate ending ever written by the community. The story doesn't stop here.
        </p>
      </div>

      {/* Controls */}
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginBottom: "18px", alignItems: "center" }}>
        {/* Filter */}
        <div style={{ display: "flex", gap: "4px" }}>
          {[["all","🌐 All"],["club","🎭 From Clubs"],["direct","🎬 From Movies"]].map(([k,l]) => (
            <button key={k} onClick={() => setFilter(k)} style={{
              fontSize: "12px", padding: "6px 14px", borderRadius: "20px",
              background: filter === k ? "rgba(99,102,241,0.65)" : "rgba(255,255,255,0.06)",
              border: "1px solid rgba(148,163,255,0.2)"
            }}>{l}</button>
          ))}
        </div>

        <div style={{ flex: 1 }} />

        {/* Sort */}
        <div style={{ display: "flex", gap: "4px" }}>
          {[["newest","🕐 Newest"],["top","🔥 Top Rated"]].map(([k,l]) => (
            <button key={k} onClick={() => setSortBy(k)} style={{
              fontSize: "12px", padding: "6px 14px", borderRadius: "20px",
              background: sortBy === k ? "rgba(99,102,241,0.65)" : "rgba(255,255,255,0.06)",
              border: "1px solid rgba(148,163,255,0.2)"
            }}>{l}</button>
          ))}
        </div>

        <button onClick={fetchArchive} style={{ fontSize: "12px", background: "rgba(255,255,255,0.07)", padding: "6px 12px", borderRadius: "10px" }}>
          ↻
        </button>
      </div>

      {loading && (
        <div style={{ textAlign: "center", padding: "40px", color: "#888" }}>
          Loading archive...
        </div>
      )}

      {!loading && sorted.length === 0 && (
        <div style={{ textAlign: "center", padding: "40px", background: "rgba(255,255,255,0.02)", borderRadius: "16px", border: "1px dashed rgba(148,163,255,0.12)" }}>
          <div style={{ fontSize: "40px", marginBottom: "12px" }}>📝</div>
          <p style={{ color: "#888", fontSize: "14px", margin: 0 }}>
            No stories yet. Click any movie and write the first alternate ending!
          </p>
        </div>
      )}

      {!loading && sorted.length > 0 && (
        <>
          <p style={{ fontSize: "12px", color: "#555", marginBottom: "14px" }}>
            {sorted.length} {sorted.length === 1 ? "story" : "stories"}
          </p>

          {sorted.map((story, i) => {
            const isExpanded = expanded === story._id;
            const preview = story.content?.slice(0, 220);
            const hasMore = story.content?.length > 220;
            const score = (story.upvotes?.length || 0) - (story.downvotes?.length || 0);
            const isFromClub = story.club && story.club !== 0;

            return (
              <div key={story._id || i} style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(148,163,255,0.09)",
                borderRadius: "16px", padding: "18px", marginBottom: "12px"
              }}>
                {/* Meta row */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "10px", gap: "8px", flexWrap: "wrap" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap" }}>
                    {/* Author avatar */}
                    <div style={{
                      width: "30px", height: "30px", borderRadius: "50%", flexShrink: 0,
                      background: `linear-gradient(135deg, hsl(${(story.user?.name?.charCodeAt(0) || 65) * 5 % 360},65%,52%), hsl(${(story.user?.name?.charCodeAt(0) || 65) * 9 % 360},70%,38%))`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: "12px", fontWeight: 800, color: "white"
                    }}>
                      {(story.user?.name || "A")[0].toUpperCase()}
                    </div>
                    <span style={{ fontSize: "13px", fontWeight: 600, color: "#c7d2fe" }}>
                      {story.user?.name || "Anonymous"}
                    </span>
                    <span style={{ fontSize: "11px", color: "#444" }}>·</span>
                    <span style={{ fontSize: "11px", color: "#555" }}>
                      {new Date(story.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                    </span>
                    <span style={{
                      fontSize: "10px", padding: "2px 8px", borderRadius: "12px",
                      background: isFromClub ? "rgba(99,102,241,0.2)" : "rgba(245,158,11,0.15)",
                      color: isFromClub ? "#a5b4fc" : "#fcd34d",
                      border: `1px solid ${isFromClub ? "rgba(99,102,241,0.3)" : "rgba(245,158,11,0.3)"}`
                    }}>
                      {isFromClub ? `🎭 Club #${story.club}` : "🎬 Movie Submission"}
                    </span>
                  </div>

                  {/* Right side stats */}
                  <div style={{ display: "flex", gap: "10px", alignItems: "center", fontSize: "12px", color: "#555" }}>
                    <span>👍 {story.upvotes?.length || 0}</span>
                    <span style={{ color: score > 0 ? "#4ade80" : score < 0 ? "#f87171" : "#555", fontWeight: 600 }}>
                      {score > 0 ? `+${score}` : score} pts
                    </span>
                    <span>{story.content?.trim().split(/\s+/).length || 0} words</span>
                  </div>
                </div>

                {/* Content */}
                <p style={{ fontSize: "13px", color: "#c4c9e2", lineHeight: 1.8, margin: "0 0 10px", whiteSpace: "pre-wrap" }}>
                  {isExpanded ? story.content : preview}
                  {!isExpanded && hasMore && <span style={{ color: "#555" }}>...</span>}
                </p>

                {hasMore && (
                  <button
                    onClick={() => setExpanded(isExpanded ? null : story._id)}
                    style={{ fontSize: "12px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(148,163,255,0.15)", borderRadius: "8px", padding: "5px 12px", color: "#a5b4fc" }}
                  >
                    {isExpanded ? "Show less ↑" : "Read full ending ↓"}
                  </button>
                )}
              </div>
            );
          })}
        </>
      )}
    </div>
  );
}

export default Archive;
