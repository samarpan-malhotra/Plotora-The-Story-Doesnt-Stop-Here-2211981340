const API_KEY = "a5e63ae4fb2d1178b3d73905c853c8cf";
const BASE = "https://api.themoviedb.org/3";

async function request(url) {
  try {
    const res = await fetch(url);
    const data = await res.json();
    if (!res.ok) throw new Error(data.status_message || "TMDB error");
    return data;
  } catch (err) {
    console.error("TMDB ERROR:", err.message);
    return { results: [] };
  }
}

export const tmdb = {
  // Movies
  trending:    () => request(`${BASE}/trending/movie/week?api_key=${API_KEY}`),
  upcoming:    () => request(`${BASE}/movie/upcoming?api_key=${API_KEY}`),
  popular:     () => request(`${BASE}/movie/popular?api_key=${API_KEY}`),
  topRated:    () => request(`${BASE}/movie/top_rated?api_key=${API_KEY}`),
  nowPlaying:  () => request(`${BASE}/movie/now_playing?api_key=${API_KEY}`),
  action:      () => request(`${BASE}/discover/movie?api_key=${API_KEY}&with_genres=28&sort_by=popularity.desc`),
  scifi:       () => request(`${BASE}/discover/movie?api_key=${API_KEY}&with_genres=878&sort_by=popularity.desc`),
  horror:      () => request(`${BASE}/discover/movie?api_key=${API_KEY}&with_genres=27&sort_by=popularity.desc`),
  animation:   () => request(`${BASE}/discover/movie?api_key=${API_KEY}&with_genres=16&sort_by=popularity.desc`),
  romance:     () => request(`${BASE}/discover/movie?api_key=${API_KEY}&with_genres=10749&sort_by=popularity.desc`),

  // TV Shows
  tvTrending:  () => request(`${BASE}/trending/tv/week?api_key=${API_KEY}`),
  tvPopular:   () => request(`${BASE}/tv/popular?api_key=${API_KEY}`),
  tvTopRated:  () => request(`${BASE}/tv/top_rated?api_key=${API_KEY}`),
  tvAiring:    () => request(`${BASE}/tv/on_the_air?api_key=${API_KEY}`),
  tvAction:    () => request(`${BASE}/discover/tv?api_key=${API_KEY}&with_genres=10759&sort_by=popularity.desc`),
  tvDrama:     () => request(`${BASE}/discover/tv?api_key=${API_KEY}&with_genres=18&sort_by=popularity.desc`),

  // Detail endpoints (work for both movie and tv)
  details:     (id, type = "movie") => request(`${BASE}/${type}/${id}?api_key=${API_KEY}`),
  credits:     (id, type = "movie") => request(`${BASE}/${type}/${id}/credits?api_key=${API_KEY}`),
  videos:      (id, type = "movie") => request(`${BASE}/${type}/${id}/videos?api_key=${API_KEY}`),
  similar:     (id, type = "movie") => request(`${BASE}/${type}/${id}/similar?api_key=${API_KEY}`),
  recommendations: (id, type = "movie") => request(`${BASE}/${type}/${id}/recommendations?api_key=${API_KEY}`),

  // Search both
  search:      (q) => request(`${BASE}/search/multi?api_key=${API_KEY}&query=${encodeURIComponent(q)}`),
  byGenre:     (id) => request(`${BASE}/discover/movie?api_key=${API_KEY}&with_genres=${id}`),
};
