const BASE_URL = "http://localhost:5000/api"; // change if deployed

async function request(endpoint, method = "GET", data, token) {
  try {
    const res = await fetch(`${BASE_URL}${endpoint}`, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...(token && { Authorization: `Bearer ${token}` })
      },
      ...(data && { body: JSON.stringify(data) })
    });

    const result = await res.json();

    if (!res.ok) {
      throw new Error(result.message || "Something went wrong");
    }

    return result;

  } catch (err) {
    console.error("API ERROR:", err.message);
    throw err;
  }
}

export const api = {
  // 🔐 AUTH
  login(data) {
    return request("/auth/login", "POST", data);
  },

  register(data) {
    return request("/auth/register", "POST", data);
  },

  // 👤 USER (optional future use)
  me(token) {
    return request("/auth/me", "GET", null, token);
  },

  // 🎭 CLUBS (future-ready)
  createClub(data, token) {
    return request("/clubs", "POST", data, token);
  },

  getClubs() {
    return request("/clubs");
  }
};