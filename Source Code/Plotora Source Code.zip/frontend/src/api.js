const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

async function request(path, method = 'GET', body = null, token = null) {
  try {
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers.Authorization = `Bearer ${token}`;

    console.log("API CALL:", `${API}${path}`); // 🔍 debug

    const res = await fetch(`${API}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    });

    let data;
    try {
      data = await res.json();
    } catch {
      throw new Error("Server not responding");
    }

    if (!res.ok) {
      throw new Error(data?.message || "Request failed");
    }

    return data;

  } catch (err) {
    if (err.message === "Failed to fetch") {
      throw new Error("Backend not running OR wrong API URL");
    }
    throw err;
  }
}

export const api = {
  register: (data) => request('/auth/register', 'POST', data),
  login: (data) => request('/auth/login', 'POST', data),
  me: (token) => request('/auth/me', 'GET', null, token),
  listClubs: () => request('/clubs'),
  createClub: (data, token) => request('/clubs', 'POST', data, token),
  clubDetails: (id, token) => request(`/clubs/${id}`, 'GET', null, token),
  joinClub: (id, token) => request(`/clubs/${id}/join`, 'POST', {}, token),
  addMovie: (id, data, token) => request(`/clubs/${id}/movies`, 'POST', data, token),
  voteMovie: (id, data, token) => request(`/clubs/${id}/vote`, 'POST', data, token),
  submitEnding: (id, data, token) => request(`/clubs/${id}/endings`, 'POST', data, token),
  voteEnding: (id, data, token) => request(`/clubs/${id}/endings/vote`, 'POST', data, token),
  leaderboard: (id, token) => request(`/clubs/${id}/leaderboard`, 'GET', null, token)
};
