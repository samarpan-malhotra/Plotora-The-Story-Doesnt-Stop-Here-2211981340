import Club from '../models/Club.js';
import Movie from '../models/Movie.js';
import Vote from '../models/Vote.js';
import Ending from '../models/Ending.js';
import EndingVote from '../models/EndingVote.js';

function isDeadlinePassed(deadline) {
  return new Date() > new Date(deadline);
}

async function refreshSelectedMovie(clubId) {
  const topMovie = await Movie.find({ club: clubId }).sort({ voteCount: -1, createdAt: 1 }).limit(1);
  if (topMovie.length) {
    await Club.findByIdAndUpdate(clubId, { selectedMovie: topMovie[0]._id });
  }
}

export async function listClubs(req, res) {
  const clubs = await Club.find().populate('createdBy', 'name email').sort({ createdAt: -1 });
  res.json(clubs);
}

export async function createClub(req, res) {
  const { name, description, votingDeadline } = req.body;
  if (!name || !votingDeadline) return res.status(400).json({ message: 'Name and deadline required' });

  const club = await Club.create({
    name,
    description: description || '',
    createdBy: req.user._id,
    members: [req.user._id],
    votingDeadline
  });
  res.status(201).json(club);
}

export async function joinClub(req, res) {
  const club = await Club.findById(req.params.id);
  if (!club) return res.status(404).json({ message: 'Club not found' });

  if (!club.members.some((m) => m.toString() === req.user._id.toString())) {
    club.members.push(req.user._id);
    await club.save();
  }

  res.json(club);
}

export async function clubDetails(req, res) {
  const club = await Club.findById(req.params.id)
    .populate('createdBy', 'name email')
    .populate('members', 'name email')
    .populate('selectedMovie');

  if (!club) return res.status(404).json({ message: 'Club not found' });

  const movies = await Movie.find({ club: club._id }).populate('addedBy', 'name');
  const endings = await Ending.find({ club: club._id }).populate('user', 'name').populate('movie', 'title');

  res.json({
    club,
    movies,
    endings,
    deadlinePassed: isDeadlinePassed(club.votingDeadline)
  });
}

export async function addMovie(req, res) {
  const { title, genre, language } = req.body;
  const club = await Club.findById(req.params.id);
  if (!club) return res.status(404).json({ message: 'Club not found' });

  if (isDeadlinePassed(club.votingDeadline)) {
    return res.status(400).json({ message: 'Voting deadline is over' });
  }

  if (!title) return res.status(400).json({ message: 'Title required' });

  const movie = await Movie.create({
    title,
    genre: genre || '',
    language: language || '',
    club: club._id,
    addedBy: req.user._id
  });
  res.status(201).json(movie);
}

export async function voteMovie(req, res) {
  const { movieId } = req.body;
  const club = await Club.findById(req.params.id);
  if (!club) return res.status(404).json({ message: 'Club not found' });

  if (isDeadlinePassed(club.votingDeadline)) {
    return res.status(400).json({ message: 'Voting deadline is over' });
  }

  const movie = await Movie.findById(movieId);
  if (!movie || movie.club.toString() !== club._id.toString()) {
    return res.status(404).json({ message: 'Movie not found' });
  }

  const existing = await Vote.findOne({ club: club._id, user: req.user._id });
  if (existing) return res.status(400).json({ message: 'You have already voted' });

  await Vote.create({ club: club._id, movie: movie._id, user: req.user._id });
  movie.voteCount += 1;
  await movie.save();

  await refreshSelectedMovie(club._id);

  const updatedClub = await Club.findById(club._id).populate('selectedMovie');
  res.json({ message: 'Vote recorded', selectedMovie: updatedClub.selectedMovie });
}

export async function submitEnding(req, res) {
  const { movieId, content } = req.body;
  const club = await Club.findById(req.params.id);
  if (!club) return res.status(404).json({ message: 'Club not found' });

  if (!club.selectedMovie || club.selectedMovie.toString() !== movieId) {
    return res.status(400).json({ message: 'This movie is not selected yet' });
  }

  if (!content || content.trim().length < 20) {
    return res.status(400).json({ message: 'Ending is too short' });
  }

  const ending = await Ending.create({
    club: club._id,
    movie: movieId,
    user: req.user._id,
    content
  });

  res.status(201).json(ending);
}

export async function voteEnding(req, res) {
  const { endingId } = req.body;
  const ending = await Ending.findById(endingId);
  if (!ending) return res.status(404).json({ message: 'Ending not found' });

  const existing = await EndingVote.findOne({ ending: endingId, user: req.user._id });
  if (existing) return res.status(400).json({ message: 'You already voted for this ending' });

  await EndingVote.create({ ending: endingId, user: req.user._id });
  ending.voteCount += 1;
  await ending.save();

  res.json({ message: 'Ending vote recorded' });
}

export async function leaderboard(req, res) {
  const endings = await Ending.find({ club: req.params.id })
    .populate('user', 'name')
    .populate('movie', 'title')
    .sort({ voteCount: -1, createdAt: -1 });

  res.json(endings);
}
