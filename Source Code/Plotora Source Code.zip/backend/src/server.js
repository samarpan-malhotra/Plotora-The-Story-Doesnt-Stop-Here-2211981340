import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import { connectDB } from "./config/db.js";

import authRoutes from "./routes/authRoutes.js";
import clubRoutes from "./routes/clubRoutes.js";
import storyRoutes from "./routes/story.js";   // ✅ fixed
import voteRoutes from "./routes/vote.js";     // ✅ fixed

const app = express();

/* ✅ MIDDLEWARE */
app.use(
  cors({
    origin: process.env.CLIENT_URL || "*",
    credentials: true
  })
);

app.use(express.json());

/* ✅ HEALTH CHECK */
app.get("/", (req, res) => {
  res.json({ message: "Plotora API is running" });
});

/* ✅ ROUTES */
app.use("/api/auth", authRoutes);
app.use("/api/clubs", clubRoutes);
app.use("/api/story", storyRoutes);  // ✅ fixed
app.use("/api/vote", voteRoutes);    // ✅ fixed

/* ❌ 404 HANDLER */
app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

const PORT = process.env.PORT || 5000;

/* 🚀 START SERVER */
const start = async () => {
  try {
    await connectDB(process.env.MONGO_URI);

    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
    });

  } catch (err) {
    console.error("❌ Failed to start server:", err.message);
    process.exit(1);
  }
};

start();