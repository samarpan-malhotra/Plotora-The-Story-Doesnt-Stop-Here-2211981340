import mongoose from 'mongoose';

const endingVoteSchema = new mongoose.Schema(
  {
    ending: { type: mongoose.Schema.Types.ObjectId, ref: 'Ending', required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
  },
  { timestamps: true }
);

endingVoteSchema.index({ ending: 1, user: 1 }, { unique: true });

export default mongoose.model('EndingVote', endingVoteSchema);
