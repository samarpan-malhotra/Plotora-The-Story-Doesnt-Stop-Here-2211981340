import mongoose from "mongoose";

const voteSchema = new mongoose.Schema(
  {
    // 🎭 Using genre ID as club (from TMDB)
    club: {
      type: Number,
      required: true
    },

    // 🎬 Using TMDB movie ID
    movie: {
      type: Number,
      required: true
    },

    // 👤 User from your auth system
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    }
  },
  { timestamps: true }
);

// 🚫 One vote per user per club
voteSchema.index({ club: 1, user: 1 }, { unique: true });

export default mongoose.model("Vote", voteSchema);