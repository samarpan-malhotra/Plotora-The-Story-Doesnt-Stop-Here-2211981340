import mongoose from 'mongoose';

const clubSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    description: { type: String, default: '' },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    members: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    votingDeadline: { type: Date, required: true },
    selectedMovie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie', default: null }
  },
  { timestamps: true }
);

export default mongoose.model('Club', clubSchema);
