import mongoose from "mongoose";

const storySchema = new mongoose.Schema(
  {
    club:    { type: Number, default: 0 },   // TMDB genre id (0 = submitted directly from movie modal)
    movie:   { type: Number, required: true }, // TMDB movie id
    user:    { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    content: { type: String, required: true },
    upvotes:   [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    downvotes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  },
  { timestamps: true }
);

export default mongoose.model("Story", storySchema);
