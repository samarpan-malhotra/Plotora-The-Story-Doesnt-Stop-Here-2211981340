import mongoose from 'mongoose';

const movieSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    genre: { type: String, default: '' },
    language: { type: String, default: '' },
    club: { type: mongoose.Schema.Types.ObjectId, ref: 'Club', required: true },
    addedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    voteCount: { type: Number, default: 0 }
  },
  { timestamps: true }
);

export default mongoose.model('Movie', movieSchema);
