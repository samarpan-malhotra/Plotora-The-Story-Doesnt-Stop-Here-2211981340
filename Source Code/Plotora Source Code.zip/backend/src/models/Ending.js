import mongoose from 'mongoose';

const endingSchema = new mongoose.Schema(
  {
    club: { type: mongoose.Schema.Types.ObjectId, ref: 'Club', required: true },
    movie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie', required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    content: { type: String, required: true, trim: true, maxlength: 2500 },
    voteCount: { type: Number, default: 0 }
  },
  { timestamps: true }
);

export default mongoose.model('Ending', endingSchema);
