import express from "express";
import Vote from "../models/Vote.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();

/* POST /api/vote — cast a vote */
router.post("/", protect, async (req, res) => {
  try {
    const { clubId, movieId } = req.body;
    if (!clubId || !movieId) {
      return res.status(400).json({ message: "Missing data" });
    }

    // One vote per user per club
    const existing = await Vote.findOne({ user: req.user._id, club: clubId });
    if (existing) {
      return res.status(400).json({ message: "Already voted in this club" });
    }

    const vote = await Vote.create({
      user: req.user._id,
      club: clubId,
      movie: movieId
    });

    res.json({ message: "Vote added", vote });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Vote failed" });
  }
});

/* GET /api/vote/:clubId — vote counts + current user's vote */
router.get("/:clubId", protect, async (req, res) => {
  try {
    const votes = await Vote.find({ club: req.params.clubId });

    // Count votes per movie
    const counts = {};
    votes.forEach(v => {
      counts[v.movie] = (counts[v.movie] || 0) + 1;
    });

    // Check if user already voted
    const myVote = votes.find(v => v.user.toString() === req.user._id.toString());

    res.json({ counts, myVote: myVote ? myVote.movie : null });
  } catch (err) {
    res.status(500).json({ message: "Error fetching votes" });
  }
});

/* GET /api/vote/:clubId/public — public vote counts only (no auth) */
router.get("/:clubId/public", async (req, res) => {
  try {
    const votes = await Vote.find({ club: req.params.clubId });
    const counts = {};
    votes.forEach(v => {
      counts[v.movie] = (counts[v.movie] || 0) + 1;
    });
    res.json({ counts });
  } catch (err) {
    res.status(500).json({ message: "Error fetching votes" });
  }
});

export default router;
