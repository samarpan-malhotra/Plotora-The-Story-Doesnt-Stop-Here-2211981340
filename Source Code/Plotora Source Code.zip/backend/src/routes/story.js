import express from "express";
import Story from "../models/Story.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();

/* ─────────────────────────────────────────────────────────────
   ALL specific named routes MUST come before wildcard /:id routes
   ───────────────────────────────────────────────────────────── */

/* GET /api/story/archive/all — all stories, newest first (for Archive page) */
router.get("/archive/all", async (req, res) => {
  try {
    const stories = await Story.find()
      .populate("user", "name")
      .sort({ createdAt: -1 });
    res.json(stories);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error fetching archive" });
  }
});

/* GET /api/story/movie/:movieId — all endings for a specific movie (modal) */
router.get("/movie/:movieId", async (req, res) => {
  try {
    const stories = await Story.find({ movie: Number(req.params.movieId) })
      .populate("user", "name")
      .sort({ createdAt: -1 });
    res.json(stories);
  } catch (err) {
    res.status(500).json({ message: "Error fetching stories" });
  }
});

/* GET /api/story/club/:clubId — stories for a genre club */
router.get("/club/:clubId", async (req, res) => {
  try {
    const stories = await Story.find({ club: Number(req.params.clubId) })
      .populate("user", "name")
      .sort({ createdAt: -1 });
    res.json(stories);
  } catch (err) {
    res.status(500).json({ message: "Error fetching stories" });
  }
});

/* POST /api/story — submit an alternate ending */
router.post("/", protect, async (req, res) => {
  try {
    const { clubId, movieId, content } = req.body;
    if (!movieId || !content) {
      return res.status(400).json({ message: "Missing fields" });
    }
    const wordCount = content.trim().split(/\s+/).length;
    if (wordCount < 20) return res.status(400).json({ message: "Minimum 20 words required" });
    if (wordCount > 500) return res.status(400).json({ message: "Maximum 500 words allowed" });

    const story = await Story.create({
      club:      clubId ? Number(clubId) : 0,
      movie:     Number(movieId),
      user:      req.user._id,
      content,
      upvotes:   [],
      downvotes: []
    });
    await story.populate("user", "name");
    res.json({ message: "Story added", story });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to add story" });
  }
});

/* POST /api/story/:id/vote — upvote or downvote */
router.post("/:id/vote", protect, async (req, res) => {
  try {
    const { type } = req.body;
    if (!["up", "down"].includes(type)) {
      return res.status(400).json({ message: "Invalid vote type" });
    }
    const story = await Story.findById(req.params.id);
    if (!story) return res.status(404).json({ message: "Story not found" });

    const userId = req.user._id.toString();
    const hasUpvoted   = story.upvotes.map(id => id.toString()).includes(userId);
    const hasDownvoted = story.downvotes.map(id => id.toString()).includes(userId);

    if (type === "up") {
      if (hasUpvoted) {
        story.upvotes = story.upvotes.filter(id => id.toString() !== userId);
      } else {
        story.upvotes.push(req.user._id);
        story.downvotes = story.downvotes.filter(id => id.toString() !== userId);
      }
    } else {
      if (hasDownvoted) {
        story.downvotes = story.downvotes.filter(id => id.toString() !== userId);
      } else {
        story.downvotes.push(req.user._id);
        story.upvotes = story.upvotes.filter(id => id.toString() !== userId);
      }
    }

    await story.save();
    const uid = req.user._id.toString();
    res.json({
      upvotes:   story.upvotes.length,
      downvotes: story.downvotes.length,
      userVote:  story.upvotes.map(id => id.toString()).includes(uid) ? "up"
               : story.downvotes.map(id => id.toString()).includes(uid) ? "down" : null
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Vote failed" });
  }
});

/* DELETE /api/story/:id — delete your own story */
router.delete("/:id", protect, async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);
    if (!story) return res.status(404).json({ message: "Story not found" });
    if (story.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorised" });
    }
    await story.deleteOne();
    res.json({ message: "Deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Delete failed" });
  }
});

export default router;
