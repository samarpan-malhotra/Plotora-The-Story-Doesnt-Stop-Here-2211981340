import { Router } from 'express';
import { addMovie, clubDetails, createClub, joinClub, leaderboard, listClubs, submitEnding, voteEnding, voteMovie } from '../controllers/clubController.js';
import { protect } from '../middleware/auth.js';

const router = Router();

router.get('/', listClubs);
router.post('/', protect, createClub);
router.get('/:id', protect, clubDetails);
router.post('/:id/join', protect, joinClub);
router.post('/:id/movies', protect, addMovie);
router.post('/:id/vote', protect, voteMovie);
router.post('/:id/endings', protect, submitEnding);
router.post('/:id/endings/vote', protect, voteEnding);
router.get('/:id/leaderboard', protect, leaderboard);

export default router;
